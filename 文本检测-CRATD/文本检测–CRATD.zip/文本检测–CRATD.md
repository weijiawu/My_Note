# 文本检测--CRATD

---
<Excerpt in index | 首页摘要> 
 **<font color = #80000>Character Region Awareness for Text Detection**
**KeyWords Plus**:     &#160;&#160;&#160;&#160;     	**CVPR2019**&#160;&#160;&#160;&#160;  **Curved Text**
- **paper** ：[new version paper](https://arxiv.org/abs/1903.12473)
-  **NAVER**：line的母公司，韩国的最大的互联网公司，字符级别的文字检测，采用了**CAM热力图的操作去检测每一个字符**
<!-- more -->
<The rest of contents | 余下全文>

## Introduction

&#160;&#160;&#160;&#160; **字符级别的文本检测网络，用的是分水岭算法生成label，采用heatmaps去得到激活值最大的目标区域，有点attention的感觉。**
### 1、论文创新点

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;1.提出了一篇字符级别的检测算法

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;2.预测得到 :**<font color=#0088888>1.The character region score** &#160;&#160;&#160;&#160;    **<font color=#0088888>2. Affinity score**.  The region score is used to **localize individual characters** in the image, and the affinity score is used to **group each character into a single instance.** 

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;3.Propose a **weakly- supervised learning framework** that estimates character- level ground truths in existing real word-level datasets.

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;<div align=center>![Alt text](./15570381211.png)




### 2、算法主体

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;改论文主要预测**每个字符区域和字符之间的一个紧密程度预测**，因为没有字符级别的label，所以模型训练在一个**弱监督的方式下**。网络的backbone采用VGG16，之后接上采样最终输出两个通道：**the region score and the affinity score**

<div align=center> ![Alt text](./1557043153569.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;训练在一个**弱监督学习的方式下**，有人造合成的数据集具有字符级别的label，real image没有字符级别的标注时，自己检测合成产生label再进行训练。如上图所示，对真实场景中的数据集和人造合成的数据集有不同的训练方式。


### 3、label generation

<div align=center> ![Alt text](./1557041657974.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;分别产生**Region Score GT** 和**Affinity Score GT**
the following steps to approximate and generate the ground truth for both the region score and the affinity score: 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;1) prepare a **2-dimensional isotropic Gaussian map;** 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;2) **compute perspective transform** between the Gaussian map region and each character box; 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;3) **warp Gaussian map** to the box area.
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;使用**小感受野也能预测大文本和长文本**，只需要关注字符级别的内容而不需要关注整个文本实例。

<div align=center>![Alt text](./1557043740891.png)

三步产生字符级别的label：
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;1、抠出文本级别的内容
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;2、预测region score区域
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;3、运用分水岭算法
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;4、得到字符基本的文字框
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;5、贴上文字框

为了防止在弱监督方式下产生的错误label带偏网络，该论文提出了一个评价方式（虽然我没有咋看明白），大概就是计算一个

 <div align=center>![Alt text](./1557048156865.png)

### 4、Post-processing
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;正常文本后处理分为以下几步：

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;1、首先对0-1之间的概率图进行取阈值计算
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;2、使用Connected Component Labeling(CCL) 进行区域连接
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;3、最后使用opencv的MinAreaRect去框出最小的四边形区域


<div align=center>  ![Alt text](./15570485321.png)


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**不规则文本检测后处理**分为以下几步（如上图所示）：

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;1、先找到扫描方向的局部最大值**（blue line）**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;2、连接所有the local maxima上的中心点叫做中心线
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;3、然后将**the local maxima lines**旋转至于中心线垂直
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;4、**the local maxima lines**上的端点是文本控制点的候选点，为了能更好的覆盖文本，将文本最外端的两个控制点分别向外移动**the local maxima lines**的半径长度最为最终的控制点。

### 5、Experiment Results

<div align=center> ![Alt text](./1557113197467.png)
**ICD13-ICD15-ICD17**

<div align=center>![Alt text](./1557113351581.png)
**Total-CTW**

### 6、Conclusion and Future work
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;个人观点：**不太受感受野的限制，只关注单个文字，对于长文本和不规则文本不必特意去设置相应大小的卷积提升感受野。**


## 反馈与建议
- 邮箱：<weij  ia_wu@yeah.net>