# 文本检测--EAST

---
<Excerpt in index | 首页摘要> 
 **<font size = 5><font color = #80000>Detecting Text In Natural Image With connectionist text proposal network**
**KeyWords Plus**:     &#160;&#160;&#160;&#160;     CVPR, 2017      
- **relevant blog** ：[EAST: An Efficient and Accurate Scene Text Detector](https://blog.csdn.net/zhangwei15hh/article/details/79899300) 
- **paper** ：[EAST](https://arxiv.org/abs/1704.03155v2)
- **coding** ：[Github](https://github.com/argman/EAST)
- **PPT** ：[My_Note](https://github.com/weijiawu/My_Note/tree/master/%E6%96%87%E6%9C%AC%E6%A3%80%E6%B5%8B-EAST)
<!-- more -->
<The rest of contents | 余下全文>

## 指标

### 1、评价指标

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**Precision**又叫查准率，**Recall**又叫查全率。这两个指标共同衡量才能评价模型输出结果。
* `TP`: 预测为1(Positive)，实际也为1(Truth-预测对了)
* `TN`: 预测为0(Negative)，实际也为0(Truth-预测对了)
* `FP`: 预测为1(Positive)，实际为0(False-预测错了)
* `FN`: 预测为0(Negative)，实际为1(False-预测错了)
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**总的样本**个数为：`TP+TN+FP+FN。`

* `Accuracy` = (预测正确的样本数)/(总样本数)=**(TP+TN)/(TP+TN+FP+FN)**
* `Precision` = (预测为1且正确预测的样本数)/(所有预测为1的样本数) = **TP/(TP+FP)**
* `Recall` = (预测为1且正确预测的样本数)/(所有真实情况为1的样本数) = **TP/(TP+FN)**
* `F-score` = 2*(`Precision`*`Recall`)/(`Precision`+`Recall`)


### 2、TensorFlow中的tf.metrics算子

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;[深入理解TensorFlow中的tf.metrics算子](https://www.jianshu.com/p/7d22c58c90e7)

<div align=center> ![Alt text](./1541082161.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**ICDAR 2015** is used in Challenge 4 of ICDAR 2015 Robust Reading Competition [15]. It includes a total of **1500 pictures**, **1000** of which are used for **training** and the **remaining** are for **testing**.
<div align=center> ![Alt text](./15408286881.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**COCO-Text**  is the largest text detection dataset to date. It reuses the images from **MS-COCO dataset** . A total of **63,686** images are **annotated**, in which **43,686** are chosen to be the **training** set and the rest **20,000** for **testing**.
<div align=center>  ![Alt text](./15408288241.png)


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**MSRA-TD500**  is a dataset comprises of **300 training images** and **200 test images.** Text regions are of arbitrary orientations and annotated at sentence level. Different from the other datasets, it contains text in **both English and Chinese.**
<div align=center>  ![Alt text](./15408287891.png)



### 3、ICDAR
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;  [ICDAR 2017 Robust Reading competitions](http://rrc.cvc.uab.es/?com=introduction)官网有专门的评价函数，可以得出**三个指标**：
  
<div align=center> ![Alt text](./1541816817053.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#888000><font size=5>预测结果：**

**论文中：**
<div align=center>![Alt text](./15422632051.png)

**实测：**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font size=5><font color=#990900>Recall**: 0.772267 &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font size=5><font color=#990900>Precision**: 0.846437 &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font size=5><font color=#990900>F-score**: 0.807653



## 基本网络结构



### Introduction

The contributions of this work are three-fold: 

*  We propose a scene text detection method that consists of **two stages**: a Fully Convolutional Network and an NMS merging stage. **The FCN directly produces text regions, excluding redundant and time-consuming intermediate steps.** 
* The pipeline is ﬂexible to produce either word level or line level predictions, whose geometric shapes can be **rotated boxes or quadrangles**, depending on speciﬁc applications. 
* The proposed algorithm signiﬁcantly **outperforms** state-of-the-art methods in both **accuracy and speed.**

<div align=center>![Alt text](./15418173071.png)


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;该模型直接预测全图像中**任意方向**和四边形形状的单词或文本行，**消除不必要的中间步骤**（例如，候选聚合和单词分割）。通过下图它与一些其他方式的步骤对比，可以发现该模型的步骤比较简单，去除了中间一些复杂的步骤，所以符合它的特点，EAST, since it is an Efficient and Accuracy Scene Text detection pipeline.
<div align=center> ![Alt text](./20180411162012451.png)
**网络结构**

### 第一步
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font size=5><font color=#666000>Feature extractor stem(PVANet)**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;利用Inception的思想，即不同尺寸的卷积核的组合可以适应多尺度目标的检测，作者在这里采用PVANet模型，我们也可以用VGG16或者其他的常见网络，**提取不同尺寸卷积核下的特征并用于后期的特征组合**。 

### 第二步
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font size=5><font color=#666000>Feature-merging branch**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;在这一部分用来组合特征，并**通过上池化和concat恢复到原图的尺寸**，这里借鉴的是U-net的思想。 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;所谓上池化一般是指**最大池化的逆过程**，实际上是不能实现的但是，可以通过只把池化过程中最大激活值所在的位置激活，其他位置设为0，完成上池化的近似过程。 
<div align=center>   ![Alt text](./20180411163320797.png)

```
 for i in range(4):
        print('Shape of f_{} {}'.format(i, f[i].shape))
    g = [None, None, None, None]
    h = [None, None, None, None]
    num_outputs = [None, 128, 64, 32]
    for i in range(4):
        if i == 0:
            h[i] = f[i]  # 计算h
        else:
            c1_1 = slim.conv2d(tf.concat([g[i-1], f[i]], axis=-1), num_outputs[i], 1)
            h[i] = slim.conv2d(c1_1, num_outputs[i], 3)
        if i <= 2:
            g[i] = unpool(h[i]) # 计算g
        else:
            g[i] = slim.conv2d(h[i], num_outputs[i], 3)
        print('Shape of h_{} {}, g_{} {}'.format(i, h[i].shape, i, g[i].shape))
```

### 第三步
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font size=5><font color=#666000>Output Layer**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;第二部分的输出通过一个**（1x1，1）的卷积核**获得score_map。score_map与原图尺寸一致，每一个值代表此处**是否有文字的可能性**。 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;第二部分的输出通过一个**（1x1，4）的卷积核**获得RBOX 的geometry_map。有四个通道，分别代表**每个像素点到文本矩形框上，右，底，左边界的距离**。另外再通过一个（1x1, 1）的卷积核获得该框的旋转角，这是为了能够识别出有旋转的文字。 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;第二部分的输出通过一个（**1x1，8）的卷积核**获得QUAD的geometry_map，八个通道分别代表**每个像素点到任意四边形的四个顶点的距离。** 

<div align=center> ![Alt text](./20180411164420012.png)


## 代价函数
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#006000>代价函数分两部分**
* 第一部分是分类误差，
* 第二部分是几何误差，文中权衡重要性，λg=1。 

<div align=center>![Alt text](./20180411165024585.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font size=5><font color=#444000>具体参考[blog](https://blog.csdn.net/zhangwei15hh/article/details/79899300?utm_source=blogxgwz1)**


<div align=center> ![Alt text](./15418182041.png)




### 分类误差函数

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;采用` class-balanced cross-entropy`，这样做可以很实用的处理正负样本不均衡的问题。 来自[Holistically-Nested Edge Detection](https://arxiv.org/pdf/1504.06375.pdf)
<div align=center>![Alt text](./20180411165337694.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**其中：**
<div align=center>![Alt text](./20180411165450453.png)

### 几何误差函数

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#007777>1、对于RBOX，采用IoU loss**

<div align=center> ![Alt text](./20180411165722788.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;where $\hat{R}$ represents the **predicted** AABB geometry and ${R_{}}^{*}$ is its corresponding ground truth.

<div align=center>  ![Alt text](./20170504234932860.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**角度误差为：**
<div align=center>![Alt text](./20180411165810776.png)



&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#007777>2、对于QUAD采用smoothed L1 loss **
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#007777>CQ={x1,y1,x2,y2,x3,y3,x4,y4} **

<div align=center> ![Alt text](./20180411165859740.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;where $\hat{\theta }$ is the prediction to the **rotation angle** and ${\theta_{}}^{*}$ represents the **ground truth**.
## 导入数据

```
icdar.py
		-generator:
			1、得到文本下的所有图片路径   image_list = np.array(get_images())
			2、循环读取图片和对应的txt文本信息内容   
			      im = cv2.imread(im_fn)                                 
			      text_polys, text_tags = load_annoataion(txt_fn)     #得到坐标和文本内容 
			      text_polys：    文本坐标
			      text_tags ：    内容信息   
			3、 检测得到的文本坐标信息是否有效：
				  text_polys, text_tags = check_and_validate_polys(text_polys, text_tags, (h, w))  
				  #检测得到的文本坐标是否有效
			4、按比例任意缩放图片大小
			5、从图片中任意剪切一块面积下来
			      im, text_polys, text_tags = crop_area(im, text_polys, text_tags, crop_background=True)
			6、最后经过一些列的计算得到
			       1、input_images：图片
			       2、input_score_maps：分数标记
			       3、input_geo_maps：RBOX
			       4、input_training_masks：训练标记
			      
```

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#088000>具体流程参考load_image.py文件分析**



## 评价指标计算


 &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;   `python script.py -g='gt.zip' -s='submhome/weijia.wu/workspace/Paper/ICDAR_test/' -p='0.8'`




## 反馈与建议
- 微博：[@柏林designer](https://weibo.com/5072970539/profile?topnav=1&wvr=6&is_all=1)
- 邮箱：<wwj123@zju.edu.cn>
