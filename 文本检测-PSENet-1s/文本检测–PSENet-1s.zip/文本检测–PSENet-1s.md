# 文本检测--PSENet-1s

---
<Excerpt in index | 首页摘要> 
 **<font color = #80000>Shape Robust Text Detection with Progressive Scale Expansion Network**
**KeyWords Plus**:     &#160;&#160;&#160;&#160;     	**CVPR2019**&#160;&#160;&#160;&#160;  **Curved Text**&#160;&#160;&#160;&#160;  **Face++**
- **paper** ：[new version paper](https://arxiv.org/abs/1903.12473)
- **Github**: [PSENet](https://github.com/whai362/PSENet)
<!-- more -->
<The rest of contents | 余下全文>

## Introduction

&#160;&#160;&#160;&#160; PSENet 分好几个版本，最新的一个是**19年的CVPR**，这是一篇南京大学和face++合作的文章（好像还有好几个机构的人），19年出现了很多不规则文本检测算法，TextMountain、Textfield等等，不过为啥我要好好研究这个**（因为这篇文章开源了代码。。。）**。
### 1、论文创新点

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;1、Propose a novel kernel-based framework, namely, **Progressive Scale Expansion Network (PSENet)**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;2、Adopt a progressive scale expansion algorithm based on **Breadth-First-Search (BFS)**： 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;（1）、Starting from the kernels with **minimal scales** (instances can be distinguished in this step) &#160;&#160;&#160;&#160;
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;（2）、**Expanding their areas** by involving more pixels in larger kernels gradually&#160;&#160;&#160;&#160;
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;（3）、Finish- ing until the complete text instances (**the largest kernels)** are explored.


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;这个文章主要做的创新点大概就是**预测多个分割结果，分别是S1,S2,S3...Sn**代表不同的等级面积的结果，S1最小，基本就是文本骨架，Sn最大。然后在后处理的过程中，先用**最小的预测结果去区分文本，再逐步扩张成正常文本大小**。。。

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;<div align=center>![Alt text](./1555675863497.png)



### 2、算法主体

<div align=center>  ![Alt text](./15556635401.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;We firstly get four 256 channels feature maps **(i.e. P2, P3, P4, P5)** from the backbone. To further combine the semantic features from low to high levels, we fuse the four feature maps to get **feature map F with 1024 channels** via the function C(·) as:

<div align=center> ![Alt text](./1555676411086.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;先backbone下采样得到**四层的feature maps**，再通过**fpn**对四层feature分别进行**上采样2,4,8倍**进行融合得到输出结果。

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;如上图所示，网络有三个分割结果，分别是S1,S2,S3.首先利用最小的kernel生成的**S1来区分四个文本实例，然后再逐步扩张成S2和S3**


### 3、label generation

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;产生不同尺寸的S1....Sn需要**不同尺寸的labels**

<div align=center> ![Alt text](./1555678343330.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**不同尺寸的labels**生成如上图所示，缩放比例可以用下面公式计算得出：

<div align=center> ![Alt text](./1555678718972.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;这个$d_{i}$表示的是缩小后mask边缘与正常mask边缘的距离，缩放比例rate $r_{i}$可以由下面计算得出：

<div align=center> ![Alt text](./1555679016959.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**m是最小mask的比例**，n在m到1之间的值，成线性增加。

### 4、Loss Function
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Loss 主要分为**分类的text instance loss和shrunk losses**，L是平衡这两个loss的参数。分类loss主要用了交叉熵和dice loss。

<div align=center> ![Alt text](./1555679624956.png)


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;The dice coefficient **D(Si, Gi)** 被计算如下：

<div align=center>![Alt text](./1555680429288.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;$L_{s}$ 被计算如下：

<div align=center>![Alt text](./1555680555957.png)



### 4、Datasets

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#0077777><font size=5>SynthText**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Contains about **800K** synthetic images. 

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#0077777><font size=5>TotalText**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Newly-released benchmark for text detection. Besides horizontal and multi-Oriented text instances.The dataset is split into **training and testing sets with 1255 and 300 images**, respectively.

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#0077777><font size=5>CTW1500**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;CTW1500 dataset **<font color=#00888888>mainly consisting of curved text**. It consists of **<font color=#00888888>1000 training images and 500 test images**. Text instances are annotated with polygons with **<font color=#00888888>14 vertexes.**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#0077777><font size=5>ICDAR 2015**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Icdar2015 is a commonly used dataset for text detection. It contains a **total of 1500 pictures**, 1000 of which are used for training and the remaining are for testing. The


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#0077777><font size=5>ICDAR 2017 MLT**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ICDAR 2017 MIL is a large scale multi-lingual text dataset, which includes **7200 training im- ages, 1800 validation images and 9000 testing images.**

### 5、Experiment Results

**<font size =5 ><font color=#0088888>Implementation Details** 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;All the networks are optimized by using stochastic gradient **descent (SGD).**The **data augmentation** for training data is listed as follows: 1) the images are rescaled with ratio {0.5, 1.0, 2.0, 3.0} randomly; 2) the images are horizon- tally flipped and rotated in the range [−10◦, 10◦] randomly; 3) 640 × 640 random samples are cropped from the trans- formed images.

<div align=center>![Alt text](./1555681452234.png)
**Total-Text**


<div align=center>![Alt text](./1555681423357.png)
**CTW1500**


<div align=center>![Alt text](./1555681538497.png)
**ICDAR 2015**


<div align=center>![Alt text](./1555681258572.png)
**IC17-MLT**


<div align=center>![Alt text](./1555681620666.png)




### 6、Conclusion and Future work


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;个人观点：这个文章其实做的只是一件事情，就是用**预测得到的小的mask区分文本，然后逐渐扩张形成正常大小的文本mask**，个人最近发了一篇比较水的会议论文也是检测不规则文本的：TextCohesion: Detecting Text for ArbitraryShapes，其实本质是和这个文章是差不多的（我发之前还没看过这个文章，好像也没有被收录），不过算法主体是不一样的，我这个文章过几天也会挂到arxiv上，主要也是用小的mask区分文本实例，但是我不是进行扩展，我是讲除了**文本骨架外的文本像素给不同的方向预测，使得四周的文本像素对文本骨架有一个类似于“聚心力”的作用，最终形成一个文本实例**。pipeline如下（在total和ctw1500上实验指标蛮高，暂时第一）：

<div align=center>![Alt text](./1555682105257.png)

## 反馈与建议
- 微博：[@柏林designer](https://weibo.com/5072970539/profile?topnav=1&wvr=6&is_all=1)
- 邮箱：<weijia_wu@yeah.net>