# 文本检测--TextSnake

---
<Excerpt in index | 首页摘要> 
 **<font color = #80000>TextSnake: A Flexible Representation for Detecting Text of Arbitrary Shapes**
**KeyWords Plus**:     &#160;&#160;&#160;&#160;     	**ECCV 2018**&#160;&#160;&#160;&#160;  **Curved Text**
- **relevant blog** ：[旷视科技提出TextSnake](https://www.jiqizhixin.com/articles/2018-09-07-13)  &#160;&#160;&#160;&#160; 
- **paper** ：[TextSnake](https://arxiv.org/abs/1807.01544)
- **Github**: [TextSnake.pytorch](https://github.com/princewang1994/TextSnake.pytorch)
<!-- more -->
<The rest of contents | 余下全文>

## Introduction


### 1、论文创新点

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**1、Propose a flexible and general representation for scene text of `arbitrary shapes`**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**2、Predict the    Text Center Line (TCL)     &#160;&#160;&#160;&#160;     Radius r   &#160;&#160;&#160;&#160;          Orientation θ  &#160;&#160;&#160;&#160;        Text regions (TR)**


<div align=center>  ![Alt text](./1547384093696.png)


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;如上图所示，该论文的创新点主要在于提出一个类似于文本蛇的检测方式对**不规则文本进行预测**，事实上自然场景中多数如下图所示的文本，所以按照正常矩形框的检测方式显然无法有效的解决这种情况。因为自然场景中的文本可以各种形状，但本质不变的就是他必然是一个不断层的文本（所以我相信作者可能也是基于这个想用很多圆去拟合文本。）
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;该算法主要做的是五个任务：**1、预测文本  2、预测文本中心线 3、预测一个文本中15个圆的半径  4、预测中心线与圆心的sin  5、预测cos**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;

<div align=center> ![Alt text](./1547384280084.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;对于这种弯曲并且非平行视角的文本而言，传统的矩形框检测显然不够用了，而且**不规则文本也是之后的发展方向**，有心的读者如何观察18年下半年的论文趋势，可以发现基本找不到以往的矩形框文本检测方式的，大多顶会论文都是针对不规则文本或者是通用文本所提出的解决方法。

### 2、算法主体

<div align=center> ![Alt text](./1547388009616.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;In order to detect text with **arbitrary shapes**, we employ an **FCN** model to predict the geometry attributes of text instances.The FCN based network predicts score maps of text center line **(TCL)** and text regions **(TR)**, together with geometry attributes, including **r, cosθ and sinθ.** 

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color = #0099999>网络框架**

<div align=center> ![Alt text](./1547388180642.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;网络框架如上图所示，采用VGG16，抽取五层的feature map进行融合预测。
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;下面就是融合上采样的方法，采样五层特征，深层先上采样然后与浅层进行融合，再用一个（1*1）卷积和（3*3）的卷积核进行卷积运算。

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color = #0099999>上采样**

<div align=center>![Alt text](./1547388908801.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color = #0099999>产生label**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**Extracting Text Center Line** 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;For **triangles and quadrangles,** it’s easy to directly calculate the TCL with algebraic methods, since in this case, TCL is a straight line. 

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;It has two edges that are respectively the **head and the tail**. The two edges near the head or tail are running **parallel but in opposite direction.**
<div align=center>![Alt text](./1547390129045.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;主要思路是先找到文本的两个端点和边线，然后按照边线的1/2去寻找中心线，除去两边的端点就是**中心线的label。**

### 3、Loss
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Loss 主要分为**分类loss和回归loss**，分类TR和TCL为分类loss，半径角度这些为回归loss，TR和TCL使用的是交叉熵，并加入了**Oinline hard negative mining** 去解决正负样本不平衡问题。

<div align=center> ![Alt text](./1548161066704.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**Regression loss使用Smoothed loss**计算，并且这些只对tcl内的计算，对tcl外的像素没有任何意义。

<div align=center>![Alt text](./1548161396704.png)

### 4、Datasets

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#0077777><font size=5>SynthText**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Contains about **800K** synthetic images. 

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#0077777><font size=5>TotalText**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Newly-released benchmark for text detection. Besides horizontal and multi-Oriented text instances.The dataset is split into **training and testing sets with 1255 and 300 images**, respectively.

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#0077777><font size=5>CTW1500**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;another dataset **<font color=#00888888>mainly consisting of curved text**. It consists of **<font color=#00888888>1000 training images and 500 test images**. Text instances are annotated with polygons with **<font color=#00888888>14 vertexes.**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#0077777><font size=5>ICDAR 2015**


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#0077777><font size=5>MSRA-TD500**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;A dataset with **multi-lingual, arbitrary-oriented and long text lines.** It includes **300 training images and 200 test images** with text line level annotations

### 5、Experiment Results


<div align=center>![Alt text](./1548161483025.png)
**Total-Text**


<div align=center>![Alt text](./1548161522318.png)
**CTW1500**


<div align=center>![Alt text](./1548161566536.png)
**ICDAR 2015**


<div align=center>![Alt text](./24_img650.jpg)



### 6、Conclusion and Future work


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;这篇**paper**在不规则场景文本检测里面也算是先锋者了，不规则场景文本检测的**paper**大多数都是18年后半年迸发的，但是人个感觉得这个**paper**的方法不是很好，比较繁琐，有很多可以改进的地方。


## 反馈与建议
- 微博：[@柏林designer](https://weibo.com/5072970539/profile?topnav=1&wvr=6&is_all=1)
- 邮箱：<weijia_wu@yeah.net>