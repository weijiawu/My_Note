# 文本检测--PixelLink

---
<Excerpt in index | 首页摘要> 
 **<font size = 5><font color = #80000>PixelLink: Detecting Scene Text via Instance Segmentation**
**KeyWords Plus**:     &#160;&#160;&#160;&#160;     	AAAI-2018    
- **relevant blog** ：[文本行检测之PixelLink](https://blog.csdn.net/qq_14845119/article/details/80953555)  &#160;&#160;&#160;&#160;  [知乎 文本行检测之PixelLink](https://zhuanlan.zhihu.com/p/38171172)  
- **paper** ：[PixelLink](https://arxiv.org/abs/1704.03155v2)
- **coding** ：[Github](https://github.com/ZJULearning/pixel_link)
<!-- more -->
<The rest of contents | 余下全文>

## Introduction


### 1、论文创新点
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font size =5><font color=#009000>The main idea of the paper**
* A novel scene text detection algorithm based on **<font color=#006000>instance segmentation**（Outside regression）
* A CNN model is trained to perform two kinds of **<font color=#007333>pixel-wise** predictions: **<font color=#004000>text/non-text prediction** and **<font color=#004000>link prediction**.


### 2、文本检测
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**Most state-of-the-art scene text detection algorithms** are deep learning based methods that depend on bounding box regression and perform **at least** two kinds of predictions: 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#003000>1、text/nontext classification**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#003000>2、location regression**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font size=4>Classification**: 输入是图片，输出是判断概率结果，判断是一只猫，这个叫做**分类任务**。

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font size=4>Regression**: 输入是图片，输出是坐标，寻找到这张图里面猫在哪个位置，这个叫做**回归任务**。

<div align=center> ![Alt text](./1542266623831.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#920000>如上图所示，就是分类和回归问题的主要区别**

<div align=center> ![Alt text](./1542267027375.png)
   
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#920000>如上图所示,虽然文本框的回归在以往的文本检测中扮演着重要的角色，但是他并不是不可缺少的，因为基于像素点的文本二分类也包括着位置坐标信息。**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#420000>但是这里就有个问题了，如上图所示，如果单纯的用文本二分类（语义分割）来定位检测文本，因为文本之间相距较近导致无法分割开来。**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#120000>所以作者引入了实例分割来解决这个问题，下面就是语义分割与实例分割得区别。**

### 3、实例分割
<div align=center> ![Alt text](./1542269417524.png)


**如上图所示：**
   
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;	**<font color=#990000>场景识别（Scene Recognition）**：将不同的图片按照其所示环境进行分类，意在缩小计算机与人类对于场景理解的差异。

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;	**<font color=#990000>物体检测（Object Detection）**：物体检测主要包含两个问题，一个是判断属于某个特定类的物体是否出现在图中；二是对该物体进行定位。主要实现，输入测试图片，输出检测到物体的类别和位置。

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;	**<font color=#990000>语义分割（Semantic Segmentation）**：判断图片中的某一像素属于**某个物体类别**。同一个物体的不同实例不需要单独分割出来。如测试图片中有多头羊，**只需区分出羊这个大类**，不需要具体分出羊1，羊2，等。

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;	**<font color=#990000>实例分割（Instance Segment）**：实例分割是**物体检测与语义分割的综合体**。相对于物体检测的方框，实例分割可精确到物体的边缘；相对于语义分割，实例分割可以标注出图上同一类别物体的**不同个体（牛1，牛2，牛3等）**。


## 网络框架

### 1、整体框架
<div align=center> ![Alt text](./15422702721.png)


**<font size=5>PixelLink**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;     1.**Text/Non-text prediction**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;     2.**Link Prediction**(`innovation`)


&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#823456>Although it’s hard to distinguish among texts, we can solve this problem via link prediction.**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;PixelLink detects text via instance segmentation, where predicted positive pixels are joined together into text instances **by predicted positive links**. Bounding boxes are then directly **extracted from this segmentation result.**

### 2、网络框架

&#160;&#160;&#160;&#160;&#160;&#160;&#160;Structure of PixelLink+VGG16 2s. fc6 and fc7 are converted into convolutional layers. The **upsampling** operation is done through bilinear **interpolation** directly. Feature maps from different stages are fused through a cascade of **upsampling and add operations**. All pooling layers except pool5 take a stride of 2, and pool5 takes 1. Therefore, the size of fc7 is the same as conv5 3, and no upsampling is needed when adding scores from these two layers. ‘conv 1  1,2(16)’ stands for a 11 convolutional layer with **2 or 16 kernels**, for text/non-text prediction or link prediction individually.

<div align=center> ![Alt text](./1542271512862.png)

&#160;&#160;&#160;&#160;&#160;&#160;&#160;整个实现过程包括两部分：先通过深度学习网络预测`pixel positive`和`link positive`，并根据`link positive`连接`pixel positive`得到文本实例分割图，然后从分割图中直接提取文本行的bbox.具体步骤如下：

* 主干网络是沿用了SSD网络结构．具体来说：首先用**VGG16作为base net**，并将VGG16的最后两个**全连接层改成卷积层**．
* 提取不同层的feature map，对于PixelLink+VGG16 2s网络结构：提取了`conv2_2, conv3_3, conv4_3, conv5_3, fc_7`．
* 对已提取的特征层，采用自顶向下的方法进行融合，融合操作包括先向上采样，然后再进行add操作．注意：这里包含了两种操作：`pixel cls`和`pixel link`，对应的卷积核个数分别为２和16
* 对于网络输出层，包括**文本/非文本预测和Link预测**． 


### 3、Linking Pixels Together

&#160;&#160;&#160;&#160;&#160;&#160;&#160;通过设定两个不同的阈值，可以得到`pixel positive`集合和`link positive`集合，然后根据link positive将pixel positive进行连接，得到`CCs(conected compoents)`集合，**集合中的每个元素代表的就是文本实例**．这里需要特别注意：给定两个相邻的pixel positive，它们之间的link预测是由当前两个pixel共同决定的．而当前两个pixel需要连接(即两个像素属于同一个文本实例)的前提条件：**two link中至少有一个link positive．连接的规则采用的是Disjoint set data structure(并查集)的方法．**

<div align=center> ![Alt text](./1542288888239.png)

### 4、Extraction of Bounding Boxes

&#160;&#160;&#160;&#160;&#160;&#160;&#160;基于上述语义分割的结果(即上述的CCs)，直接通过`opencv`的`minAreaRext`提取文本的带方向信息的外接矩形框(即带角度信息)，具体的格式为`((x,y),(w,h),θ)`，分别表示中心点坐标，当前bbox的宽和高，旋转角度． 
&#160;&#160;&#160;&#160;&#160;&#160;&#160;这里和`SegLink`的关键区别：`PixelLink`是直接从分割结果中提取bbox，而`SegLink`采用的是边框回归.


### 5、Post Filtering after Segmentation

&#160;&#160;&#160;&#160;&#160;&#160;&#160;之所以要进行后处理，是因为在`pixel`进行连接的时候不可避免地会引入噪声．文中主要是对已检测的bbox通过一些简单的`几何形状判断`(包括bbox的宽，高，面积及宽高比等，这些主要是在对应的训练集上进行统计的出来的)进行filter．经过后处理后，可以提升`文本行检出的准确率`．


### 6、训练

&#160;&#160;&#160;&#160;&#160;&#160;&#160;像素间的`link`生成规则：给定一个像素，若其与邻域的８像素都属于同一个文本实例，则将其link标注为`positive`，否则标注为`negative `。
&#160;&#160;&#160;&#160;&#160;&#160;&#160;这里值得注意的是：`ground truth`的计算是在缩放后(具体缩放的比例与其预测的`feature map`大小一致)的原图上进行的。


## Loss Function


&#160;&#160;&#160;&#160;&#160;&#160;&#160;The training loss is a weighted **<font color=#005000>sum of loss on pixels and loss on links**:


<div align=center> ![Alt text](./15422907871.png)

### 1、Loss on Pixels

`Instance-Balanced Cross-Entropy Loss:`

<div align=center>![Alt text](./15422910761.png)


`Positive pixels weight:`


<div align=center>  ![Alt text](./15422914501.png)

<div align=center>![Alt text](./15422915131.png)


`Negative pixels weight: `

&#160;&#160;&#160;&#160;&#160;&#160;&#160;**Online Hard Example Mining (OHEM)**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;More specifically, `r*S negative pixels` with the highest losses are selected, by setting their weights to ones.` r` is the `negative-positive ratio` and is set to 3 as a common practice.


**<font color=#009000>As a result, pixels in small instances have a higher weight, and pixels in large instances have a smaller weight.**

### 2、Loss on Links

`Class-balanced cross-entropy loss:`

<div align=center> ![Alt text](./15422918961.png)


`Losses for positive and negative links are calculated separately and on positive pixels only:`

<div align=center>![Alt text](./15422920421.png)

<div align=center>![Alt text](./15422921481.png)



## Coding

### 数据处理

#### 使用TFRecords读取数据

&#160;&#160;&#160;&#160;&#160;&#160;&#160;`tfrecord`数据文件是一种将图像数据和标签统一存储的`二进制文件`，能**更好的利用内存**，在`tensorflow`中快速的复制，移动，读取，存储等.

优点：

* **读取速度快**

缺点：

* **需要额外生成TFRecords，占用较大内存（当然生成好后就不用管了）**

### Feature map 融合、上采样

```
def _fuse_by_cascade_conv1x1_upsample_sum(self, num_classes, scope):
    import config
    num_layers = len(config.feat_layers)
    
    with tf.variable_scope(scope):
        smaller_score_map = None
        for idx in range(0, len(config.feat_layers))[::-1]: #[4, 3, 2, 1, 0]
            current_layer_name = config.feat_layers[idx]
            current_layer = self.end_points[current_layer_name]
            current_score_map = self._score_layer(current_layer, 
                                  num_classes, current_layer_name)
            if smaller_score_map is None:
                smaller_score_map = current_score_map
            else:
                upscore_map = self._upscore_layer(smaller_score_map, current_score_map)
                smaller_score_map = current_score_map + upscore_map
        
    return smaller_score_map
```


## Result


### 1、数据集得分

&#160;&#160;&#160;&#160;&#160;&#160;&#160;**论文：**
<div align=center>![Alt text](./15422924301.png)
&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#008000>ICDAR2015**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;**实测：**

&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;`Recall`: **0.81608088**,   `Precision`: **0.8543346**,      `F-score`: **0.8347697**

### 2、分析

&#160;&#160;&#160;&#160;&#160;&#160;&#160;When it comes to `PixelLink`, neurons on the prediction layer only have to observe the status of` itself and its neighboring pixels `on the feature map. In another word, PixelLink has the least requirement on receptive fields and the `easiest task` to learn for neurons among listed methods.


&#160;&#160;&#160;&#160;&#160;&#160;&#160;The link design is important because it converts **semantic segmentation** into **instance segmentation**, indispensable for the separation of nearby texts in PixelLink.



&#160;&#160;&#160;&#160;&#160;&#160;&#160; PixelLink can be trained from scratch with `less data(1k)` in `fewer iterations`, while achieving on par or better performance on several benchmarks tha state-of-the-art methods based on location regression.

&#160;&#160;&#160;&#160;&#160;&#160;&#160; **<font color=#006000>The main task of text detection is pixel classification, and Pixel link take this to extremes, the biggest innovation is link classification.**
&#160;&#160;&#160;&#160;&#160;&#160;&#160;**<font color=#006000>Content of PixelLink are all classification tasks without regression, the advantage is leaning easier , training faster, less data.**



## 反馈与建议
- 微博：[@柏林designer](https://weibo.com/5072970539/profile?topnav=1&wvr=6&is_all=1)
- 邮箱：<wwj123@zju.edu.cn>
