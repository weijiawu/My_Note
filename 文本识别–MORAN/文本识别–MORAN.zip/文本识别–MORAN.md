# 文本识别--MORAN

---
<Excerpt in index | 首页摘要> 
 **<font color = #80000>[MORAN: A Multi-Object Rectified Attention Network for Scene Text Recognition](https://arxiv.org/pdf/1901.03003.pdf)**
**KeyWords Plus**:     &#160;&#160;&#160;&#160;     Scene text recognition&#160;&#160;&#160;&#160; optical character recognition
- **relevant blog** ：[MORAN不规则文本纠正：刷新多个OCR数据集最优算法](https://blog.csdn.net/weixin_41770169/article/details/86541456)  

- **paper** ：[MORAN](https://arxiv.org/pdf/1901.03003.pdf)
- **coding** ：[Github](https://github.com/HCIILAB/MORAN_v2)
<!-- more -->
<The rest of contents | 余下全文>

## Introduction
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;**MORAN**是一种文本识别算法，可以针对不规则文本进行处理
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160; **MORAN**文本识别算法由矫正子网络**MORN**和识别子网络**ASRN**组成，在**MORN**中设计了一种新颖的**像素级弱监督学习机制用于不规则文本的形状纠正**，大大降低了不规则文本的识别难度。

<div align=center> ![Alt text](./15513214391.png)

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160; The training of the **MORN** is guided by the **ASRN**, which requires only text labels. Without any `geometric-level or pixel-level supervision`, the MORN is trained in a `weak supervision way.`

**<font color=0056677>几个创新点和论文贡献：**

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;1、propose the MORAN framework to recognize **irregular scene text.**
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;2、Trained in a **weak supervision** way, the subnetwork MORN is flexible. It is free of geometric constraints and can rectify images with complicated distortion.
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;3、propose a **fractional pickup method** for the training of the attention-based decoder in the ASRN. To address noise perturbations, we expand the visual field of the MORAN, which further improves the sensitivity of the attentionbased decoder.

## Multi-Object Rectification Network

<div align=center>  ![Alt text](./1551323496.png)

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;Comparison of the **MORN and affine transformation.** The MORN is free of geometric constraints. The main direction of rectification predicted by the MORN for each character is indicated by a **yellow arrow.**
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;在**黄色和蓝色之间的像素补偿是0**，颜色的深浅程度代表着补偿的量级，矫正网络如下。
<div align=center> ![Alt text](./15513457451.png)

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;place a pooling layer before the convolutional layer to **avoid noise and reduce the amount of calculation.**

<div align=center> ![Alt text](./1551323893644.png)

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;Similar to the offset maps, the grid contains two channels, which represent the xcoordinate and y-coordinate
如下图所示，通过补偿网络会产生一个**offset maps**，他有两个通道分别代表着x和y方向上的补偿信息，同时也会产生一个**basic grid**用于记录original positions of the pixels。最终的补偿网络计算如下：

<div align=center>![Alt text](./15513451301.png)

<div align=center>![Alt text](./15513245021.png)
**整体的MORAN如上图所示，左边为矫正网络，右边为识别网络**

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;The **advantages of the MORN** are manifold：
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;	1、**The rectified images are more readable** owing to the regular shape of the text and the reduced noise
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160; 2、The MORN is more flexible than the affine transformation. It is free of geometric constraints，which enables it **to rectify images using complicated transformations.**
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160; 3、The MORN is **more flexible than methods using a specific** number of regressing points
free of geometric constraints，which enables it **to rectify images using complicated transformations.**
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;4、The MORN does not **require extra labelling information** of character positions.

## Attentionbased Sequence Recognition Network

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;**ASRN**网络框架如下图所示：

<div align=center> ![Alt text](./1551358329974.png)

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;先经过pooling和卷积层之后再接blstm，Each convolutional layer is followed by a batch normalization layer and a ReLU layer.

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;The largest number of steps that the decoder **generates is T**. The decoder stops processing when it predicts an end-of-sequence token “EOS" [47]. At time step t, **output yt is：**

<div align=center>![Alt text](./1551360874271.png)

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;State $s^{_{t}}$ is computed as:
<div align=center>![Alt text](./1551361057910.png)

## Fractional Pickup
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;针对一些由于噪声干扰而产生的误测，如下图所示，该论文还提出了一种措施叫做**fractional pickup**
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;An attention-based decoder trained by fractional pickup method can **perceive adjacent characters**. The wider field of attention contributes to the **robustness of the MORAN.**

<div align=center> ![Alt text](./1551361728326.png)

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;a pair of **attention weights** are selected and modified at every time step:
<div align=center>![Alt text](./1551361813194.png)

主要有以下几个优点：

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;1、**Variation of Distribution**
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;因为参数是参考临近features，而且具有随机性，增强了参数$\alpha _{}^{t,k}$,$\alpha _{}^{t,k+1}$的鲁棒性，这就造成了即使对于同一张图片，每一个step产生的贡献可能不相同，所以容易**避免过拟合和增强编码的鲁棒性。**

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;2、**Shortcut of Forward Propagation**
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;for step k + 1 in the bidirectional-LSTM, a shortcut connecting to step k is created by fractional pickup. The shortcut retains some features of the previous step in the training phase, which is the interference to the forget gate in bidirectional-LSTM.

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;3、**Broader Visual Field**
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;Without fractional pickup, the error term of sequence feature vector $h{}^{k}$ is
<div align=center>![Alt text](./1551367137011.png)

结果只和一个固定的参数相关，但是加入了fractional pickup以后，等式就变成了：

<div align=center>![Alt text](./1551367250541.png)

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;结果不仅与当前的feature相关，也与相邻的features相关，back-propagated gradients are able to **dynamically optimize** the decoder over a **broader range of neighbouring regions.**

## Performance of the MORAN

<div align=center>![Alt text](./1551367661007.png)

<div align=center>![Alt text](./1551367720631.png)


## Limitation of the MORAN
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;because of complicated background, the MORAN will fail when the **curve angle is too large.**

<div align=center>![Alt text](./1551367846673.png)

## Conclusion

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;The proposed framework involves two stages: **rectification and recognition.** First, a multiobject rectification network, which is free of geometric constraints and flexible enough to handle complicated deformations, was proposed to transform an image containing **irregular text into a more readable one.**The proposed MORAN is trained in **a weak-supervised way,** which requires **only images and the corresponding text labels.**

## 反馈与建议
- 微博：[@柏林designer](https://weibo.com/5072970539/profile?topnav=1&wvr=6&is_all=1)
- 邮箱：<weijia_wu@yeah.net>