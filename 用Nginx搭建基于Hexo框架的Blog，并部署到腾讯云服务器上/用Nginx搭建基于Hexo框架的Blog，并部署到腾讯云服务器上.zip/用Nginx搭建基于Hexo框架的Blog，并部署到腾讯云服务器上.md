
# 用Nginx搭建基于Hexo框架的Blog，并部署到腾讯云服务器上



---
<Excerpt in index | 首页摘要> 
用Nginx搭建基于Hexo框架的Blog，并部署到腾讯云服务器上。
主题：[yelee](http://moxfive.coding.me/yelee/2.Basic-Usage/)<!-- more -->
<The rest of contents | 余下全文>


  
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160; 2018.7.14这一天我终于搭建完了我的网站，之前一直有写笔记，但是觉得还是写在属于自己的网页博客上才是最完美的，所以花了几天时间买了域名和腾讯云服务器搭建了这个网页，希望这个blog能帮助我更好的总结。因为搭建过程中出现了很多问题，第一篇就写这个了。

-------------------

## 自己搭建过程中遇见的问题：

   1、希望自己以后不要在不懂指令作用之前就按网页的一些流程走，会出现很多问题，比如这次我的Nginx就装出了问题，最后还是重装了云服务器的系统从新装一遍才解决的。

   2、以后得熟悉Linux下面的开发流程，熟悉shell指令


### 搭建流程本文主要参考了[TyCoding的博客](https://blog.csdn.net/tycoding/article/details/80480541)：

### 1、首先
  
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160; 我们简单需要了解一下 [Hexo](https://hexo.io/zh-cn/docs/),这里见不再说明了。

### 2、搭建
 
&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;  请先在本地安装好git(直接官网下载)和[NodeJs](https://nodejs.org/en/download/)，之后再安装Hexo。

&#160;&#160;&#160;&#160; &#160;&#160;&#160;&#160;   安装之后可以在git界面输入：

>git --version
>node --version

   验证一波。

### 3、安装

>$ npm install -g hexo-cli

### 4、初始化一个hexo文档
     你可以选定一个文件夹路径为存放这个博客源码的路径，然后在终端输入 hexo init Test 初始化hexo，（这里的Test是你博客项目的名称，也可以指定为Blog）
完成后就会发现我们的源文件夹会出现下列目录结构：
<div align=center> ![Alt text](./1.PNG)


   然后我们使用终端利用cd命令进入这个文件夹中 cd Test
   进入项目源文件后，输入 hexo s —debug就能启动项目了：
   
<div align=center>![Alt text](./捕获.PNG)




可以看见这个初始博客页面：
     <div align=center>![Alt text](./20180528120355275.png)

	 
    这里是使用的Hexo的默认主题配置，我们也可以使用NexT的主题配置，请到NexT官网下载，将下载后的next文件夹直接丢到themes文件夹中即可，具体使用方法请查看NexT官网： [NexT](https://hexo.io/zh-cn/docs/)
    我用的是[yelee](http://moxfive.coding.me/yelee/)的主题有兴趣的也可以了解一下。

### 5、部署到云服务器

    首先打开git终端，SSH连接远程服务器
    注意：博主这里使用的Ubuntu服务器系统，登录后默认是root用户
>ssh root@IP

     回车之后输入密码即可登录
     注意：这个IP是指你服务器的公网IP
 
### 6、安装Nginx
>yum install -y nginx

    启动Nginx服务()
	注意：ububtu平台编译环境使用apt-get install指令安装，centos平台编译环境才使用yum指令安装（下面同理）。
>service nginx start


	然后你在浏览器中输入自己的公网IP，可以看到如下：
		<div align=center>![Alt text](./2.PNG)
	证明nginx安装成功

### 7、安装git
>sudo apt-get install git-core

### 8、创建一个网站的根目录（用于存放网站的部署的静态文件）

>cd /
>mkdir var/www/Test

### 9、建立git仓库
>cd /home/
>git init --bare Test.git

### 10、配置hook

>cd  /root/Test.git/hooks
>vim post-receive

	在post-receive中写入：

>  #!/bin/bash
>rm -rf /var/www/Test
>git clone /root/Test.git /var/www/Test

	意思就是删除/var/www/Test/下的文件，并将root/Test.git下的文件clone到/var/www/Test目录下，这里注意一下，之前说过博主这里使用的是Ubuntu服务器，登录默认给予的是root权限，所以这里的/root即为/home

	然后我们赋予这个文件夹权限：

>chmod +x /root/Test.git/hooks/post-receive

### 11、配置Nginx

>vim /etc/nginx/conf.d/Test.conf

	输入以下内容：

>server{
>    listen 8080;
>    root /var/www/Test;
>}

	点击Esc键，然后输入:wq保存并退出

	重启Nginx
>service nginx restart
### 12、 本地Hexo配置

	当我们完成了上述服务器端操作时候，就要回到本地，开始配置hexo

	进入我们本地初始化的项目源文件中，看到有一个_config.yml文件，是整个项目的配置文件，打开在最后一行你会发现deploy字样，输入下列信息：

>deploy:
>   type: git
>   repo: root@IP:Test.git
	注意：这个IP是指你服务器的公网IP

### 12、 将blog发布到云服务器

	cd 进入你本地hexo创建的项目中，输入

>hexo generate
>hexo deploy

	完成以上操作后，如果你直接输入hexo d会发现显示not fount git，其实是因为我们没有在这个项目中安装git插件，cd进入项目源文件路径下输入：

>npm install hexo-deployer-git --save

	安装成功后再次发布即可。


	如果上述一切都操作成功，你就可以在浏览器输入：IP:8080查看你的项目了：

<div align=center>![Alt text](./20180528120603939.png)



## 反馈与建议
- 微博：[@柏林designer](https://weibo.com/5072970539/profile?topnav=1&wvr=6)
- 邮箱：<wwj123@zju.edu.cn>